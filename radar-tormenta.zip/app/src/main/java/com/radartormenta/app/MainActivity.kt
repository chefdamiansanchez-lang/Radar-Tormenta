package com.radartormenta.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RainTileSource(name: String, private val base: String) :
    OnlineTileSourceBase(name, 0, 7, 256, ".png", arrayOf("https://tilecache.rainviewer.com/")) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$base/256/$z/$x/$y/2/1_1.png"
    }
}

class Frame(val time: Long, val overlay: TilesOverlay)

class MainActivity : Activity() {

    private lateinit var map: MapView
    private lateinit var tvHeadline: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvFrame: TextView
    private lateinit var tvKm: TextView
    private lateinit var btnPlay: Button

    private val ui = Handler(Looper.getMainLooper())
    private val frames = ArrayList<Frame>()
    private var current = 0
    private var playing = true
    private var myLoc: MyLocationNewOverlay? = null
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val ticker = object : Runnable {
        override fun run() {
            var delay = 700L
            if (playing && frames.size > 1) {
                val next = (current + 1) % frames.size
                showFrame(next)
                if (next == frames.size - 1) delay = 1800L
            }
            ui.postDelayed(this, delay)
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 5L * 60L * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cfg = Configuration.getInstance()
        cfg.load(this, getSharedPreferences("osm", MODE_PRIVATE))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osm")
        cfg.osmdroidTileCache = File(cacheDir, "osm/tiles")

        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        tvHeadline = findViewById(R.id.tvHeadline)
        tvInfo = findViewById(R.id.tvInfo)
        tvFrame = findViewById(R.id.tvFrame)
        tvKm = findViewById(R.id.tvKm)
        btnPlay = findViewById(R.id.btnPlay)
        val btnLocate = findViewById<Button>(R.id.btnLocate)
        val btnTest = findViewById<Button>(R.id.btnTest)
        val swAlerts = findViewById<Switch>(R.id.swAlerts)
        val sbKm = findViewById<SeekBar>(R.id.sbKm)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.setTilesScaledToDpi(true)
        map.setMinZoomLevel(4.0)
        map.setMaxZoomLevel(7.0)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
        val (lat, lon) = Store.savedLocation(this)
        map.controller.setZoom(7.0)
        map.controller.setCenter(GeoPoint(lat, lon))

        swAlerts.isChecked = Store.alertsOn(this)
        swAlerts.setOnCheckedChangeListener { _, checked -> Store.setAlertsOn(this, checked) }

        sbKm.max = 80
        sbKm.progress = Store.alertKm(this) - 20
        updateKmLabel(Store.alertKm(this))
        sbKm.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val km = progress + 20
                Store.setAlertKm(this@MainActivity, km)
                updateKmLabel(km)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                refreshStatus()
            }
        })

        btnLocate.setOnClickListener {
            val p = myLoc?.myLocation
            if (p != null) {
                map.controller.animateTo(p)
            } else {
                val (la, lo) = Store.savedLocation(this)
                map.controller.animateTo(GeoPoint(la, lo))
            }
        }

        btnPlay.setOnClickListener {
            playing = !playing
            btnPlay.text = if (playing) "❚❚" else "▶"
        }

        btnTest.setOnClickListener {
            Notifier.show(
                this,
                "⚠ Aviso de prueba",
                "Así se verá una alerta cuando se acerque una tormenta."
            )
        }

        askPermissions()
    }

    private fun updateKmLabel(km: Int) {
        tvKm.text = "Avisar si la lluvia se acerca a menos de $km km"
    }

    // ---------------- Permisos

    private fun askPermissions() {
        val needed = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 1)
        } else {
            afterPermissions()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1) return
        afterPermissions()
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(
                this,
                "Para recibir avisos con la app cerrada elige \"Permitir todo el tiempo\" en ubicación",
                Toast.LENGTH_LONG
            ).show()
            requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        }
    }

    private fun afterPermissions() {
        setupLocation()
        Scheduler.ensure(applicationContext)
        loadRadar()
        ui.removeCallbacks(refresher)
        ui.post(refresher)
    }

    private fun setupLocation() {
        if (myLoc != null) return
        val ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return
        val o = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        o.enableMyLocation()
        o.runOnFirstFix(Runnable {
            runOnUiThread {
                val p = o.myLocation
                if (p != null) {
                    map.controller.animateTo(p)
                }
                refreshStatus()
            }
        })
        map.overlays.add(o)
        myLoc = o
    }

    // ---------------- Radar

    private fun loadRadar() {
        Thread {
            try {
                val json = JSONObject(StormChecker.httpGet("https://api.rainviewer.com/public/weather-maps.json"))
                val host = json.getString("host")
                val past = json.getJSONObject("radar").getJSONArray("past")
                val list = ArrayList<Pair<Long, String>>()
                for (i in 0 until past.length()) {
                    val o = past.getJSONObject(i)
                    list.add(Pair(o.getLong("time"), host + o.getString("path")))
                }
                runOnUiThread { buildFrames(list.takeLast(8)) }
            } catch (e: Exception) {
                runOnUiThread { tvFrame.text = "Sin conexión con el radar" }
            }
        }.start()
    }

    private fun buildFrames(list: List<Pair<Long, String>>) {
        for (f in frames) map.overlays.remove(f.overlay)
        frames.clear()
        val alpha = ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 1f, 0f, 0f,
                    0f, 0f, 0f, 0.85f, 0f
                )
            )
        )
        for ((t, base) in list) {
            val provider = MapTileProviderBasic(applicationContext, RainTileSource("rv_$t", base))
            val ov = TilesOverlay(provider, this)
            ov.loadingBackgroundColor = Color.TRANSPARENT
            ov.loadingLineColor = Color.TRANSPARENT
            ov.setColorFilter(alpha)
            ov.isEnabled = false
            map.overlays.add(frames.size, ov)
            frames.add(Frame(t, ov))
        }
        if (frames.isNotEmpty()) {
            current = frames.size - 1
            showFrame(current)
        }
    }

    private fun showFrame(i: Int) {
        if (frames.isEmpty() || i < 0 || i >= frames.size) return
        if (current in frames.indices) frames[current].overlay.isEnabled = false
        current = i
        frames[i].overlay.isEnabled = true
        tvFrame.text = fmt.format(Date(frames[i].time * 1000L))
        map.invalidate()
    }

    // ---------------- Estado

    private fun refreshStatus() {
        val loc = myLoc?.myLocation
        if (loc != null) Store.saveLocation(this, loc.latitude, loc.longitude)
        val (lat, lon) = Store.currentLocation(this)
        val app = applicationContext
        Thread {
            try {
                val s = StormChecker.check(app, lat, lon)
                Store.saveStatus(app, s)
                runOnUiThread { showStatus(s) }
                StormWidget.refreshAll(app)
            } catch (e: Exception) {
                runOnUiThread { tvHeadline.text = "Sin datos" }
            }
        }.start()
    }

    private fun showStatus(s: Status) {
        tvHeadline.text = s.headline
        tvHeadline.setTextColor(
            when (s.level) {
                2 -> Color.parseColor("#FF4D4D")
                1 -> Color.parseColor("#FFB020")
                else -> Color.parseColor("#3DDC84")
            }
        )
        tvInfo.text = if (s.conditions.isEmpty()) s.detail else s.detail + "\n" + s.conditions
    }

    // ---------------- Ciclo de vida

    override fun onResume() {
        super.onResume()
        map.onResume()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
        Store.loadStatus(this)?.let { showStatus(it) }
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        ui.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(refresher)
        ui.removeCallbacks(ticker)
        map.onDetach()
    }
}
